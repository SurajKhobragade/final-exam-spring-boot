package com.login.customeException;

import com.login.bean.ErrorBean;

public class DatabaseException extends RuntimeException {
	
	ErrorBean errorBean;
    public DatabaseException(ErrorBean errorBean)
    {
        super(errorBean.getErrorMessage());
        this.errorBean=errorBean;
    }

    public ErrorBean getErrorBean() {
        return errorBean;
    }

    public void setErrorBean(ErrorBean errorBean) {
        this.errorBean = errorBean;
    }

	@Override
	public String toString() {
		return "CustomeException [errorBean=" + errorBean + "]";
	}

   
}
