import { Component } from '@angular/core';
import { Router } from '@angular/router';

import { AuthService } from '../auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css',
})
export class LoginComponent {
  constructor(private router: Router, private authService: AuthService) { }

  goToSuccessPage() {
    this.router.navigate(['/success']);
  }


  login(username: string,
    password: string) {
    var obj = new LoginRequestBean(username, password);
    this.authService.login(obj).subscribe(
      (response) => {
        console.error('login successful:', response);
        this.goToSuccessPage();
      },
      (error) => {
        alert('Invalid username or Password')
        console.error('login failed:', error);
      }
    );
  }
}

class LoginRequestBean {
  loginId: string = '';
  password: string = '';

  constructor(loginId: string, password: string) {
    this.loginId = loginId;
    this.password = password;
  }

}
