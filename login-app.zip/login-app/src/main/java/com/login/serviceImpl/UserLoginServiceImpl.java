package com.login.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;

import com.login.bean.ErrorBean;
import com.login.bean.UserLoginRequest;
import com.login.customeException.DatabaseException;
import com.login.customeException.UserNotFoundException;
import com.login.entity.UserDetails;
import com.login.repository.UserRepository;
import com.login.service.UserService;

public class UserLoginServiceImpl implements UserService {

	@Autowired
	UserRepository loginRepository;

	@Override
	public UserDetails getUser(UserLoginRequest loginRequestBean) {
		try {
			UserDetails userDetail = loginRepository.findByEmailAndPassword(loginRequestBean.getLoginId(),
					loginRequestBean.getPassword());
			if (userDetail == null) {
				throw new UserNotFoundException("Invalid username/Password");
			}
			return userDetail;
		} catch (DataAccessException e) {
			ErrorBean errorBean = new ErrorBean();
			errorBean.setErrorMessage(e.getMessage());
			throw new DatabaseException(errorBean);
		}
	}

	@Override
	public UserDetails saveUser(UserDetails userDetails) {
		try {
			return loginRepository.save(userDetails);
		} catch (DataAccessException e) {
			ErrorBean errorBean = new ErrorBean();
			errorBean.setErrorMessage(e.getMessage());
			throw new DatabaseException(errorBean);
		}
	}
}
