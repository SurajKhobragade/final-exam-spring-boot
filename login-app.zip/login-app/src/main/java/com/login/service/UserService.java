package com.login.service;

import com.login.bean.UserLoginRequest;
import com.login.entity.UserDetails;

public interface UserService {
	
	 public UserDetails getUser(UserLoginRequest loginRequestBean);
	 public UserDetails saveUser(UserDetails userDetails);

}
