package com.login.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.login.bean.UserLoginRequest;
import com.login.entity.UserDetails;
import com.login.service.UserService;

@RestController
@CrossOrigin
public class signupLoginController {

	@Autowired
	UserService userService;

	@PostMapping(value = "login", path = "login")
	public ResponseEntity<UserDetails> login(@RequestBody @Validated UserLoginRequest requestBean) {
		UserDetails user = userService.getUser(requestBean);
		return new ResponseEntity<>(user, HttpStatus.OK);
	}

	@PostMapping(value = "register", path = "register")
	public ResponseEntity<UserDetails> signUp(@RequestBody @Validated UserDetails userdetails) {
		UserDetails user = userService.saveUser(userdetails);
		return new ResponseEntity<>(user, HttpStatus.CREATED);
	}
}
