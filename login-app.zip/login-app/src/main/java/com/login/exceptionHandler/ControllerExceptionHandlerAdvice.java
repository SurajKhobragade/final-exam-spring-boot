package com.login.exceptionHandler;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.login.bean.ErrorBean;
import com.login.bean.ResponseBean;
import com.login.bean.StatusCode;
import com.login.customeException.DatabaseException;
import com.login.customeException.UserNotFoundException;

@RestControllerAdvice
public class ControllerExceptionHandlerAdvice {
	@ExceptionHandler(DatabaseException.class)
    public ResponseEntity<ResponseBean> handleDatabaseException(DatabaseException ex) {
            ResponseEntity<ResponseBean> responseEntity = null;
            ResponseBean responseBean = new ResponseBean();
            List<ErrorBean> listOfErrorBean = new ArrayList<>();
            listOfErrorBean.add(ex.getErrorBean());
            responseBean.setErrorBean(listOfErrorBean);
            responseEntity = new ResponseEntity<>(responseBean, HttpStatus.INTERNAL_SERVER_ERROR);
            return responseEntity;
        
    }

	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<ResponseBean> handleInvalidArgumentException(MethodArgumentNotValidException ex) {
		List<ErrorBean> errorBeans = new ArrayList<>();
		for (FieldError error : ex.getBindingResult().getFieldErrors()) {
			ErrorBean errorBean = new ErrorBean("Field name : " + error.getField(), error.getDefaultMessage());
			errorBeans.add(errorBean);
		}
		ResponseBean responseBean = new ResponseBean();
		responseBean.setStatus(StatusCode.FAILURE);
		responseBean.setPayload(null);
		responseBean.setErrorBean(errorBeans);
		return new ResponseEntity<>(responseBean, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(UserNotFoundException.class)
	public ResponseEntity<ResponseBean> handleUserNotFoundException(UserNotFoundException ex) {
		ResponseBean responseBean = new ResponseBean();
		responseBean.setStatus(StatusCode.FAILURE);
		responseBean.setPayload(ex.getMessage());
		return new ResponseEntity<>(responseBean, HttpStatus.NOT_FOUND);
	}

}
