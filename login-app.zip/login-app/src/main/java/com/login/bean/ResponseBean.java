package com.login.bean;

import java.util.List;

public class ResponseBean {
    private Object payload;
    private List<ErrorBean> errorBean;
    private StatusCode status;

	public Object getPayload() {
        return payload;
    }

    public void setPayload(Object payload) {
        this.payload = payload;
    }

    public List<ErrorBean> getErrorBean() {
        return errorBean;
    }

    public void setErrorBean(List<ErrorBean> errorBean) {
        this.errorBean = errorBean;
    }

	public StatusCode getStatus() {
		return status;
	}

	public void setStatus(StatusCode status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "ResponseBean [payload=" + payload + ", errorBean=" + errorBean + ", status=" + status + "]";
	}
}
